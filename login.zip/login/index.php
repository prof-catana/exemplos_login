<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="logar.php" method="post">
        Usuario
        <input type="text" name="usuario">
        <br>
        Senha
        <input type="password" name="senha">
        <br>
        <input type="submit">
    </form>
</body>
</html>