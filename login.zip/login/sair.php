<?php

// Inicia a sessão
session_start();

// Destrói a sessão atual
session_destroy();

echo "Sessão finalizada!";

?>
